import bpy
import os
from mathutils import Matrix
#creates a name window and saves the name when called
class FrontiersDisplaceGroup(bpy.types.PropertyGroup):
    displace_object: bpy.props.PointerProperty(
        name="Object",
        description = "Object to displace across curve",
        type=bpy.types.Object
    )
    displace_curve: bpy.props.PointerProperty(
        name="Curve",
        description = "Curve to displace objects on",
        type=bpy.types.Object
    )
    displace_length: bpy.props.FloatProperty(
        name="Length",
        description = "Length betwe",
        default=8
    )
def displace_on_curve(curve_obj, object_obj, Length=4.0):
    if (4, 5, 0) <= bpy.app.version:
        if not "DisplaceCurveMod" in bpy.data.node_groups:
            with bpy.data.libraries.load(f'{os.path.dirname(os.path.dirname(os.path.abspath(__file__)))}/Other/DisplaceCurveMod.blend') as (data_from, data_to):
                data_to.node_groups = data_from.node_groups
        copy = curve_obj.copy()
        copy.name = "[Blendhog]CurveDisplaceObject"
        bpy.context.collection.objects.link(copy)
        if "HedgehogPath" in copy.modifiers:
            copy.modifiers["HedgehogPath"]["Socket_6"] = False
            copy.modifiers["HedgehogPath"]["Socket_7"] = False
            copy.modifiers["HedgehogPath"].show_expanded = False
        if "BlendhogDisplaceCurve" not in copy.modifiers:
            displacemodifier = copy.modifiers.new("BlendhogDisplaceCurve","NODES")
            displacemodifier.node_group = bpy.data.node_groups["BlendhogDisplaceCurve"]
            displacemodifier["Socket_2"] = object_obj
            displacemodifier["Socket_3"] = Length
        return
def realize_displaced_objects(obj):
    depsgraph = bpy.context.view_layer.depsgraph
    ob_eval = depsgraph.id_eval_get(obj)

    # Get the final evaluated geometry of an object.
    geometry = ob_eval.evaluated_geometry()
    instances_pointcloud = geometry.instances_pointcloud()
    
    if instances_pointcloud is not None:
        # This is a list containing the data that is instanced. The list may contain
        # None, objects, collections or other GeometrySets. If the geometry does not
        # have instances, the list is empty.
        references = geometry.instance_references()
        instance_transforms = instances_pointcloud.attributes["instance_transform"]
        reference_indices = instances_pointcloud.attributes[".reference_index"]
        world_matrix = ob_eval.matrix_world
        for i in range(len(instance_transforms.data)):
            mat = world_matrix @ Matrix(instance_transforms.data[i].value)  # Convert to mathutils.Matrix
            loc, rot_quat, scale = mat.decompose()
            rot_euler = rot_quat.to_euler('XYZ')
            ref = references[reference_indices.data[i].value]
            successful_instance = create_copy(ref.name, loc, rot_euler, scale)
            if successful_instance == False:
                return
                break
        bpy.data.objects.remove(obj, do_unlink=True)    
    else:
        print("No instance found")

def create_copy(name,location,rotation,scale):
        if name not in bpy.data.objects:
            print(f'Could not find original object "{name}". Cancel realization')
            return False
        org_obj = bpy.data.objects[name]
        copy = org_obj.copy()
        bpy.context.collection.objects.link(copy)
        copy.location = location
        copy.rotation_euler = rotation
        copy.scale = scale
        return True
def blendhog_display_displace_error():
    def no_displace(self,context):
        self.layout.label(text="Active object is not a displace object")
    bpy.context.window_manager.popup_menu(no_displace, title="Warning", icon='INFO')
class OBJECT_OT_DisplaceOnCurve(bpy.types.Operator):
    bl_label = "Displace on Curve"
    bl_idname = "object.displace_on_curve"
    bl_options = {'UNDO'}
    bl_description = "Create a displace object that follows the selected curve"
    def execute(self, context):
        #bpy.ops.ed.undo_push(message="Set undo step")
        displacecurve_obj = context.scene.FrontiersDisplaceGroup.displace_curve
        frontiersdisplaceobject = context.scene.FrontiersDisplaceGroup.displace_object
        Length = context.scene.FrontiersDisplaceGroup.displace_length
        displace_on_curve(displacecurve_obj, frontiersdisplaceobject, Length)
        return {'FINISHED'}

class OBJECT_OT_RealizeDisplace(bpy.types.Operator):
    bl_label = "Realize Displacement"
    bl_idname = "object.realize_displace"
    bl_options = {'UNDO'}
    bl_description = "Converts the currently active displace object into realized normal objects, which can then be used to change parameters (this destroys the connection to the curve)"

    def execute(self, context):
        obj = bpy.context.active_object
        if "BlendhogDisplaceCurve" not in obj.modifiers:
            blendhog_display_displace_error()
            return {'CANCELLED'}
        realize_displaced_objects(obj)
        return {'FINISHED'}